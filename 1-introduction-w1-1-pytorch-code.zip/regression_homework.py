#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
线性回归（课后版）——与课堂版相同的数学，但可调学习率/轮数，并输出最终权重。
"""
import argparse
import torch
from torch import nn

def build_data():
    x = torch.tensor([[-2.],[ -1.],[0.],[1.],[2.]], dtype=torch.float32)
    y = 1.0 + 0.5 * x
    return x, y

def train(lr=0.1, epochs=300, seed=0):
    torch.manual_seed(seed)
    x, y = build_data()
    model = nn.Linear(1, 1, bias=True)
    with torch.no_grad():
        model.weight.zero_()
        model.bias.zero_()
    criterion = nn.MSELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr)

    hist = []
    for t in range(epochs):
        yhat = model(x)
        loss = criterion(yhat, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        hist.append(loss.item())

    w2 = model.weight.item()
    w1 = model.bias.item()
    return (w1, w2), hist, model, x

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lr', type=float, default=0.1, help='学习率')
    parser.add_argument('--epochs', type=int, default=300, help='迭代轮数')
    args = parser.parse_args()

    (w1, w2), hist, model, x = train(lr=args.lr, epochs=args.epochs)
    print(f"[结果] w=[{w1:.6f}, {w2:.6f}]  最终 MSE={hist[-1]:.6e}")
    with torch.no_grad():
        for xi, yi_hat in zip(x.view(-1), model(x).view(-1)):
            print(f"x={xi.item(): .1f} -> ŷ={yi_hat.item():.3f}")

if __name__ == '__main__':
    main()
