#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
线性分类（课堂版）——严格使用 PDF 的三条样本与合页损失（无偏置）。
数据：(x,y) ∈ { ([0,2], +1), ([-2,0], +1), ([1,-1], -1) }，phi(x)=[x1,x2]
打分 s(x)=w^T phi(x)，预测 sign(s)。
Hinge 损失：L = (1/n) * Σ max(0, 1 - y_i s_i)
当 y_i s_i < 1 时，∂L/∂w 包含 -y_i phi(x_i)，否则为 0。
"""
import torch
from torch import nn

def hinge_mean_loss(scores, y):
    margins = y * scores
    losses = torch.clamp(1.0 - margins, min=0.0)
    return losses.mean()

def main():
    torch.manual_seed(0)

    # PDF 中的三条样本
    X = torch.tensor([[ 0.,  2.],
                      [-2.,  0.],
                      [ 1., -1.]], dtype=torch.float32)  # (n,2)
    y = torch.tensor([[+1.],
                      [+1.],
                      [-1.]], dtype=torch.float32)       # (n,1)

    # 线性模型（无偏置）
    model = nn.Linear(2, 1, bias=False)
    with torch.no_grad():
        model.weight.zero_()  # 初始 w=[0,0]

    optimizer = torch.optim.SGD(model.parameters(), lr=0.2)

    epochs = 200
    for t in range(epochs):
        scores = model(X)
        loss = hinge_mean_loss(scores, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        w = model.weight.view(-1)
        scores = model(X).view(-1)
        preds = torch.sign(scores)
        acc = (preds == y.view(-1)).float().mean().item()

    print("训练完成：")
    print(f"w = [{w[0].item():.6f}, {w[1].item():.6f}]")
    print(f"最终训练合页损失 = {loss.item():.6f}")
    print(f"训练集打分 scores = {scores.tolist()}")
    print(f"训练集预测 preds  = {preds.tolist()}")
    print(f"训练集精度 = {acc:.3f}")

if __name__ == '__main__':
    main()
