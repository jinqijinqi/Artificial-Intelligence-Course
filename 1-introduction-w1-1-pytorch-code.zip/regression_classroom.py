#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
线性回归（课堂版）——严格贴合 PDF 记号：phi(x) = [1, x]，平方损失 + 批量梯度下降。
目标函数：J(w) = (1/n) * Σ (w^T phi(x_i) - y_i)^2
梯度：∇J = (2/n) * Σ (w^T phi(x_i) - y_i) * phi(x_i)
这里用 PyTorch 的 nn.Linear(1,1)（带 bias）来等价实现：f(x) = w2 * x + w1，
其中 w1=偏置=PDF 的 w_1，w2=权重=PDF 的 w_2。
"""
import torch
from torch import nn

def main():
    # 固定随机种子以便复现实验
    torch.manual_seed(0)

    # 构造演示数据：y = 1 + 0.5 x
    x = torch.tensor([[-2.],[ -1.],[0.],[1.],[2.]], dtype=torch.float32)  # (n,1)
    y = 1.0 + 0.5 * x                                                    # (n,1)

    # 线性模型：等价于 f_w(x)=w^T [1,x]
    model = nn.Linear(in_features=1, out_features=1, bias=True)
    with torch.no_grad():
        model.weight.zero_()  # w2
        model.bias.zero_()    # w1

    criterion = nn.MSELoss(reduction='mean')
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

    # 训练
    epochs = 300
    for t in range(epochs):
        yhat = model(x)
        loss = criterion(yhat, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    # 结果
    w2 = model.weight.item()  # 对应 w_2
    w1 = model.bias.item()    # 对应 w_1
    print("训练完成：")
    print(f"w = [w1, w2] = [{w1:.6f}, {w2:.6f}]")
    print(f"最终训练 MSE = {loss.item():.6e}")
    print("在训练 x 上的预测：")
    with torch.no_grad():
        for xi, yi_hat in zip(x.view(-1), model(x).view(-1)):
            print(f"x={xi.item(): .1f} -> ŷ={yi_hat.item():.3f}")

if __name__ == '__main__':
    main()
