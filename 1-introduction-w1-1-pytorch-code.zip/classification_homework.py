#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
线性分类（课后版）——严格使用 PDF 的三条样本 + 合页损失；可调学习率/轮数。
"""
import argparse
import torch
from torch import nn

def hinge_mean_loss(scores, y):
    margins = y * scores
    losses = torch.clamp(1.0 - margins, min=0.0)
    return losses.mean()

def build_data():
    X = torch.tensor([[ 0.,  2.],
                      [-2.,  0.],
                      [ 1., -1.]], dtype=torch.float32)
    y = torch.tensor([[+1.],
                      [+1.],
                      [-1.]], dtype=torch.float32)
    return X, y

def train(lr=0.2, epochs=200, seed=0):
    torch.manual_seed(seed)
    X, y = build_data()
    model = nn.Linear(2, 1, bias=False)
    with torch.no_grad():
        model.weight.zero_()

    optimizer = torch.optim.SGD(model.parameters(), lr=lr)

    hist = []
    for t in range(epochs):
        scores = model(X)
        loss = hinge_mean_loss(scores, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        hist.append(loss.item())

    with torch.no_grad():
        w = model.weight.view(-1).detach().clone()
        scores = model(X).view(-1)
        preds = torch.sign(scores)
        acc = (preds == y.view(-1)).float().mean().item()
    return w, hist, preds, acc

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lr', type=float, default=0.2, help='学习率')
    parser.add_argument('--epochs', type=int, default=200, help='迭代轮数')
    args = parser.parse_args()

    w, hist, preds, acc = train(lr=args.lr, epochs=args.epochs)
    print(f"[结果] w=[{w[0].item():.6f}, {w[1].item():.6f}]  最终 hinge loss={hist[-1]:.6f}")
    print(f"训练集预测 preds={preds.tolist()}  精度={acc:.3f}")

if __name__ == '__main__':
    main()
